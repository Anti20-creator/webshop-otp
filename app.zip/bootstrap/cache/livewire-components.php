<?php return array (
  'cart-counter' => 'App\\Http\\Livewire\\CartCounter',
  'cart-price' => 'App\\Http\\Livewire\\CartPrice',
);