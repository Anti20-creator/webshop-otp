<div>
    <p><a href="/cart">Cart (<?php echo e($cartCount); ?>)</a></p>
</div>
<?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/livewire/cart-counter.blade.php ENDPATH**/ ?>