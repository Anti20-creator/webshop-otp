<div>
    <p> <?php echo e(Session::get('cart')->totalPrice); ?> Ft </p>
</div>
<?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/livewire/cart-price.blade.php ENDPATH**/ ?>