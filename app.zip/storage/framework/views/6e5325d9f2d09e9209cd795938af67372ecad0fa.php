<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/app.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Roboto:wght@300;400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Questrial&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <nav>
        <a href="/shop">Shop</a>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-counter')->html();
} elseif ($_instance->childHasBeenRendered('YzjLrGY')) {
    $componentId = $_instance->getRenderedChildComponentId('YzjLrGY');
    $componentTag = $_instance->getRenderedChildComponentTagName('YzjLrGY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YzjLrGY');
} else {
    $response = \Livewire\Livewire::mount('cart-counter');
    $html = $response->html();
    $_instance->logRenderedChild('YzjLrGY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/layouts/main.blade.php ENDPATH**/ ?>