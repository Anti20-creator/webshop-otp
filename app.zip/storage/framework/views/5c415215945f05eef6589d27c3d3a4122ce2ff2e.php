

<?php $__env->startSection('content'); ?>
    <div>
        <div class="col-10 row m-auto">
            <div class="col-6 p-3">
                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 d-flex">
                        <div class="col p-2">
                            <img class="w-100" src="<?php echo e(json_decode($item['item']->images)[0]); ?>" />
                        </div>
                        <div class="col p-2">
                            <p><?php echo e($item['item']->name); ?> (<?php echo e($item['size']); ?>)</p>
                            <p><?php echo e($item['item']->price); ?> Ft</p>
                            <br>
                            <div class="d-flex">
                                <form class="cart-forms remove" action="<?php echo e(route('removeFromCart')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($item['item']->id); ?>">
                                    <input type="hidden" name="size" value="<?php echo e($item['size']); ?>">
                                    <input type="hidden" name="size_id" value="<?php echo e($item['variantId']); ?>">
                                    <button>-</button>
                                </form>
                                <input class="cart-input" id="counter-<?php echo e($item['variantId']); ?>" value="<?php echo e($item['qty']); ?>">
                                <form class="cart-forms add" action="<?php echo e(route('addToCart')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($item['item']->id); ?>">
                                    <input type="hidden" name="size" value="<?php echo e($item['size']); ?>">
                                    <input type="hidden" name="size_id" value="<?php echo e($item['variantId']); ?>">
                                    <button>+</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-6">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-price')->html();
} elseif ($_instance->childHasBeenRendered('ofpnRNa')) {
    $componentId = $_instance->getRenderedChildComponentId('ofpnRNa');
    $componentTag = $_instance->getRenderedChildComponentTagName('ofpnRNa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ofpnRNa');
} else {
    $response = \Livewire\Livewire::mount('cart-price');
    $html = $response->html();
    $_instance->logRenderedChild('ofpnRNa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <form action="/pay" method="GET">
                    <?php echo csrf_field(); ?>
                    <button>Pay</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        $('.remove').submit(function(e) {
            e.preventDefault();

            $.ajax({
            type: 'POST',
            url: '../removeFromCart',
            data: $(e.currentTarget).serialize(), // serializes the form's elements.
            success: function(data)
            {
                $(e.currentTarget).siblings().find('.cart-input').prevObject[0].value = data
                Livewire.emit('updateCart')
            }
            });
        });

        $('.add').submit(function(e) {
            e.preventDefault();

            $.ajax({
            type: 'POST',
            url: '../addToCart',
            data: $(e.currentTarget).serialize(), // serializes the form's elements.
            success: function(data)
            {
                $(e.currentTarget).siblings().next('.cart-input')[0].value = data
                Livewire.emit('updateCart')
            }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/pages/cart.blade.php ENDPATH**/ ?>