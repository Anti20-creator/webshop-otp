

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-12">
            <div class="row product-details">
                <div class="col-md-6 p-4">
                    <?php $img = json_decode($product['images'])[0]; ?>
                    <?php $images = json_decode($product['images']); array_shift($images); ?>
                    <img src="<?php echo e($img); ?>" alt="" class="w-100">
                    <div class="d-flex more-images">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2 w-25" style="background-image:url(<?php echo e($image); ?>);">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-6 p-4">
                    <h5> <?php echo e($category); ?>/ </h5>
                    <h2> <?php echo e($product['name']); ?> </h2>
                    <p class="mt-3"> <?php echo e(number_format($product['price'], 0, ' ', ' ')); ?> Ft </p>
                    <hr>
                    <p> <?php echo e($product['description']); ?> </p>
                    <hr>

                    <form id="buyForm" action="<?php echo e(route('addToCart')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php
                            $sizes = \App\Models\Size::orderBy('name', 'DESC')->get()->where('product_id', $product->id);
                        ?>
                        <select name="size">
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($size->name); ?>"><?php echo e($size->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input name="product_id" type="text" hidden value="<?php echo e($product['id']); ?>">
                        <button class="add-to-cart mt-3 w-100">
                            Add to cart
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('#buyForm').submit(function(e) {
            e.preventDefault();

            $.ajax({
            type: 'POST',
            url: '../addToCart',
            data: $('#buyForm').serialize(), // serializes the form's elements.
            success: function(data)
            {
                console.log(data); // show response from the php script.
                Livewire.emit('updateCart')
            }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/product-details.blade.php ENDPATH**/ ?>