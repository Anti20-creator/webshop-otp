<div class="p-4 col-6 col-sm-4 col-md-3 ">
    <div class="product-holder">
        <a href="/product/<?php echo e($slug); ?>"> <!-- ID will go here -->
            <div class="image-holder">
                <div class="image" style="background-image: url(<?php echo e($image); ?>);">
                </div>
                <?php if($quantity <= 0): ?>
                    <div class="out-of-stock">
                        <p>Out of stock</p>
                    </div>
                <?php endif; ?>
                <?php 
                    $origin     = new DateTime("now");
                    $created_at = new DateTime($created);
                    $interval = $origin->diff($created_at)->days; 
                ?>
                <?php if($interval <= 7): ?>
                    <div class="new">
                        <p>New</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="details">
                <div class="name-with-line">
                    <div class="name"> <?php echo e($name); ?> </div>
                    <div class="line"></div>
                </div>
                <div class="price"> <?php echo e(number_format($price, 0, ' ', ' ')); ?> Ft </div>
            </div>
        </a>
    </div>
</div><?php /**PATH C:\Users\amtmanni\Documents\Works\webshop\resources\views/components/product.blade.php ENDPATH**/ ?>