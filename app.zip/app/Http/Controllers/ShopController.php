<?php

namespace App\Http\Controllers;

use App\Models\Basket;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use SimplePayStart;

class ShopController extends Controller
{
    public function index()
    {
        $products = Product::paginate(12);
        return view('shop', compact('products'));
    }

    public function product($slug)
    {
        $product = Product::all()->where('slug', $slug)->first();
        if(!$product) abort(404);

        $category = Category::all()->where('id', $product['category_id'])->first()['name'];

        return view('product-details', compact('product', 'category'));
    }

    public function cartPage()
    {
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Basket($oldCart);

        return view('pages.cart', compact('cart'));
    }

    public function addToCart(Request $request) {
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Basket($oldCart);
        $result = $cart->add($request);

        Session::put('cart', $cart);
        return $result;
    }

    public function removeFromCart(Request $request) {
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Basket($oldCart);
        $result = $cart->remove($request);

        Session::put('cart', $cart);
        return $result;
    }

    public function startPayment()
    {
        require_once 'src/config.php';
        require_once 'src/SimplePayV21.php';

        $trx = new SimplePayStart;
        $currency = 'HUF';
        $trx->addData('currency', $currency);

        $trx->addConfig($config);
        $trx->addData('total', 25);

        $trx->runStart();
    }
}
