<div>
    <p> {{Session::get('cart')->totalPrice}} Ft </p>
</div>
