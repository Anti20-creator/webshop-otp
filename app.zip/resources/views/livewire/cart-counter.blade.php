<div>
    <p><a href="/cart">Cart ({{$cartCount}})</a></p>
</div>
